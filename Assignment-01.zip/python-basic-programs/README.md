# Python Basic Programs

This repository contains basic Python programs for practical/lab work.

## Programs

| No. | File | Description |
|---|---|---|
| 1 | `01_calculator.py` | Calculator using two numbers |
| 2 | `02_even_odd.py` | Check whether a number is even or odd |
| 3 | `03_leap_year.py` | Check whether a year is a leap year |
| 4 | `04_factorial.py` | Calculate factorial using a function |
| 5 | `05_prime_number.py` | Check whether a number is prime |
| 6 | `06_sum_of_digits.py` | Find the sum of digits |
| 7 | `07_armstrong_number.py` | Check whether a number is an Armstrong number |

## Requirements

- Python 3.x

## How to Run

Open a terminal in this folder and run any program:

```bash
python 01_calculator.py
```

Replace the filename with the program you want to execute.

## Author

Sourav Patra
